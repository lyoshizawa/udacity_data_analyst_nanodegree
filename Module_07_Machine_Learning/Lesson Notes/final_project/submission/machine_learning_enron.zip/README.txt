The following files are included in this submission:

enron_fraud.pdf:  A writeup on the analysis for this project

my_dataset.pkl: The Enron dataset with three engineered features
my_classifier.pkl :  Naive Bayes classifier
my_feature_list.pkl :  The 6 best features from the dataset

poi_id.py: The script used to generate the above pkl files

resources used.txt:  A list of resources referenced for this project.